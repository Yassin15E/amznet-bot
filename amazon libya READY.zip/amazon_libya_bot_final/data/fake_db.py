"""
قاعدة البيانات الوهمية - أمازون ليبيا للاتصالات والتقنية
"""
from datetime import datetime, timedelta
import random

# ─── الباقات المتاحة ───────────────────────────────────────
PACKAGES = {
    "pkg_10": {
        "id": "pkg_10",
        "name": "باقة 10 ميغا",
        "speed": "10 Mbps",
        "upload": "5 Mbps",
        "price_monthly": 50,
        "price_3months": 140,
        "price_yearly": 540,
        "features": ["دعم فني 24/7", "بريد إلكتروني", "استخدام غير محدود"],
    },
    "pkg_20": {
        "id": "pkg_20",
        "name": "باقة 20 ميغا",
        "speed": "20 Mbps",
        "upload": "10 Mbps",
        "price_monthly": 80,
        "price_3months": 220,
        "price_yearly": 840,
        "features": ["دعم فني 24/7", "IP ثابت", "استخدام غير محدود"],
    },
    "pkg_50": {
        "id": "pkg_50",
        "name": "باقة 50 ميغا",
        "speed": "50 Mbps",
        "upload": "25 Mbps",
        "price_monthly": 130,
        "price_3months": 360,
        "price_yearly": 1380,
        "features": ["دعم فني 24/7", "IP ثابت", "استخدام غير محدود", "أولوية الشبكة"],
    },
    "pkg_100": {
        "id": "pkg_100",
        "name": "باقة 100 ميغا",
        "speed": "100 Mbps",
        "upload": "50 Mbps",
        "price_monthly": 200,
        "price_3months": 560,
        "price_yearly": 2100,
        "features": ["دعم فني 24/7", "IP ثابت", "استخدام غير محدود", "أولوية قصوى", "SLA 99.9%"],
    },
}

# ─── العملاء الوهميون ──────────────────────────────────────
FAKE_USERS = {
    "AMZN-001": {
        "contract_id": "AMZN-001",
        "password": "1234",
        "name": "محمد علي الزروق",
        "phone": "0913456789",
        "city": "طرابلس",
        "address": "حي الأندلس، شارع عمر المختار",
        "email": "mohammed@example.com",
        "package_id": "pkg_20",
        "start_date": "2024-01-15",
        "expire_date": (datetime.now() + timedelta(days=12)).strftime("%Y-%m-%d"),
        "status": "active",
        "balance": 45.0,
        "usage_gb": 58.3,
        "limit_gb": None,
        "tower": "برج طرابلس المركزي",
        "signal": "ممتاز",
    },
    "AMZN-002": {
        "contract_id": "AMZN-002",
        "password": "pass2",
        "name": "فاطمة محمود البرعصي",
        "phone": "0921234567",
        "city": "بنغازي",
        "address": "حي السلماني، شارع الجمهورية",
        "email": "fatima@example.com",
        "package_id": "pkg_50",
        "start_date": "2023-06-01",
        "expire_date": (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d"),
        "balance": 0.0,
        "status": "active",
        "usage_gb": 120.5,
        "limit_gb": None,
        "tower": "برج بنغازي الشمالي",
        "signal": "جيد جداً",
    },
    "AMZN-003": {
        "contract_id": "AMZN-003",
        "password": "abc123",
        "name": "خالد إبراهيم المنصوري",
        "phone": "0945678901",
        "city": "مصراتة",
        "address": "حي الشروق، طريق الساحل",
        "email": "khaled@example.com",
        "package_id": "pkg_10",
        "start_date": "2024-03-10",
        "expire_date": (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"),
        "balance": 120.0,
        "status": "expired",
        "usage_gb": 22.1,
        "limit_gb": None,
        "tower": "برج مصراتة الرئيسي",
        "signal": "جيد",
    },
}

# ─── الفواتير الوهمية ──────────────────────────────────────
FAKE_INVOICES = {
    "AMZN-001": [
        {"id": "INV-001-003", "date": "2024-03-01", "amount": 80, "status": "paid", "period": "مارس 2024"},
        {"id": "INV-001-002", "date": "2024-02-01", "amount": 80, "status": "paid", "period": "فبراير 2024"},
        {"id": "INV-001-001", "date": "2024-01-15", "amount": 80, "status": "paid", "period": "يناير 2024"},
    ],
    "AMZN-002": [
        {"id": "INV-002-003", "date": "2024-03-01", "amount": 130, "status": "unpaid", "period": "مارس 2024"},
        {"id": "INV-002-002", "date": "2024-02-01", "amount": 130, "status": "paid",   "period": "فبراير 2024"},
        {"id": "INV-002-001", "date": "2024-01-01", "amount": 130, "status": "paid",   "period": "يناير 2024"},
    ],
    "AMZN-003": [
        {"id": "INV-003-002", "date": "2024-03-10", "amount": 50, "status": "paid",   "period": "مارس 2024"},
        {"id": "INV-003-001", "date": "2024-02-10", "amount": 50, "status": "paid",   "period": "فبراير 2024"},
    ],
}

# ─── سجل الشحن الوهمي ─────────────────────────────────────
FAKE_RECHARGE = {
    "AMZN-001": [
        {"date": "2024-03-01", "amount": 80,  "type": "كرت شحن", "ref": "CARD-7821"},
        {"date": "2024-02-01", "amount": 80,  "type": "كرت شحن", "ref": "CARD-6543"},
        {"date": "2024-01-15", "amount": 100, "type": "دفع مسبق", "ref": "PRE-001"},
    ],
    "AMZN-002": [],
    "AMZN-003": [
        {"date": "2024-03-10", "amount": 150, "type": "كرت شحن", "ref": "CARD-9012"},
    ],
}

# ─── تذاكر الدعم الوهمية ─────────────────────────────────
FAKE_TICKETS = {}

# ─── الإشعارات الوهمية ───────────────────────────────────
FAKE_OFFERS = [
    {
        "title": "🎉 عرض رمضان",
        "desc": "اشترك في باقة 50 ميغا واحصل على شهر مجاني!",
        "valid_until": "2024-04-30",
        "discount": "25%",
    },
    {
        "title": "⚡ ترقية مجانية",
        "desc": "ترقية باقتك للضعف لمدة أسبوع مجاناً عند التجديد المبكر",
        "valid_until": "2024-05-15",
        "discount": "ترقية مجانية",
    },
    {
        "title": "👨‍👩‍👧 عرض العائلة",
        "desc": "اشترك لعدد 3 خطوط واحصل على خصم 15% على الجميع",
        "valid_until": "2024-06-30",
        "discount": "15%",
    },
]

FAKE_TOWERS = [
    {"city": "طرابلس",  "name": "برج طرابلس المركزي",   "areas": "الأندلس، الجهراء، طريق المطار", "signal": "ممتاز",   "type": "4G"},
    {"city": "طرابلس",  "name": "برج أبو سليم",          "areas": "أبو سليم، قرجي، عين زارة",     "signal": "جيد جداً","type": "4G"},
    {"city": "بنغازي",  "name": "برج بنغازي الشمالي",    "areas": "السلماني، الصابري، الفويهات",   "signal": "جيد جداً","type": "4G"},
    {"city": "مصراتة",  "name": "برج مصراتة الرئيسي",    "areas": "الشروق، القربولي، الساحل",      "signal": "جيد",     "type": "4G"},
    {"city": "الزاوية", "name": "برج الزاوية الغربية",    "areas": "وسط الزاوية، الحرشة",           "signal": "جيد",     "type": "3G"},
]

CONTACT_INFO = {
    "phones": ["📞 021-123-4567", "📞 021-765-4321"],
    "whatsapp": "0913000000",
    "email": "support@amazon-libya.ly",
    "website": "www.amazon-libya.ly",
    "facebook": "fb.com/amazonlibya",
    "address": "طرابلس، شارع عمر المختار، برج الأعمال، الطابق الخامس",
    "hours": "الأحد - الخميس: 8 صباحاً - 8 مساءً\nالجمعة - السبت: 10 صباحاً - 4 مساءً",
}

# ─── الجلسات النشطة (في الذاكرة) ─────────────────────────
SESSIONS = {}  # telegram_user_id -> contract_id
TICKETS_COUNTER = [0]

def get_user(contract_id: str):
    return FAKE_USERS.get(contract_id.upper())

def get_package(pkg_id: str):
    return PACKAGES.get(pkg_id)

def login(contract_id: str, password: str):
    user = get_user(contract_id)
    if user and user["password"] == password:
        return user
    return None

def get_session(tg_id: int):
    return SESSIONS.get(tg_id)

def set_session(tg_id: int, contract_id: str):
    SESSIONS[tg_id] = contract_id

def clear_session(tg_id: int):
    SESSIONS.pop(tg_id, None)

def add_ticket(contract_id: str, category: str, description: str):
    TICKETS_COUNTER[0] += 1
    ticket_id = f"TKT-{TICKETS_COUNTER[0]:04d}"
    ticket = {
        "id": ticket_id,
        "contract_id": contract_id,
        "category": category,
        "description": description,
        "status": "مفتوحة",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    if contract_id not in FAKE_TICKETS:
        FAKE_TICKETS[contract_id] = []
    FAKE_TICKETS[contract_id].append(ticket)
    return ticket

def get_tickets(contract_id: str):
    return FAKE_TICKETS.get(contract_id, [])

def recharge_card(contract_id: str, card_number: str):
    """محاكاة شحن كرت - أي رقم مكون من 12 رقم يشحن 50 دينار"""
    user = FAKE_USERS.get(contract_id)
    if not user:
        return None, "عقد غير موجود"
    if len(card_number) != 12 or not card_number.isdigit():
        return None, "رقم الكرت غير صحيح (يجب أن يكون 12 رقماً)"
    amount = 50
    user["balance"] += amount
    if contract_id not in FAKE_RECHARGE:
        FAKE_RECHARGE[contract_id] = []
    FAKE_RECHARGE[contract_id].insert(0, {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "amount": amount,
        "type": "كرت شحن",
        "ref": f"CARD-{card_number[-4:]}",
    })
    return amount, None

def renew_subscription(contract_id: str, months: int):
    user = FAKE_USERS.get(contract_id)
    if not user:
        return None, "عقد غير موجود"
    pkg = PACKAGES.get(user["package_id"])
    if months == 1:
        cost = pkg["price_monthly"]
    elif months == 3:
        cost = pkg["price_3months"]
    elif months == 12:
        cost = pkg["price_yearly"]
    else:
        cost = pkg["price_monthly"] * months

    if user["balance"] < cost:
        return None, f"الرصيد غير كافٍ. الرصيد الحالي: {user['balance']} د.ل، المطلوب: {cost} د.ل"

    user["balance"] -= cost
    current_expire = datetime.strptime(user["expire_date"], "%Y-%m-%d")
    if current_expire < datetime.now():
        current_expire = datetime.now()
    new_expire = current_expire + timedelta(days=30 * months)
    user["expire_date"] = new_expire.strftime("%Y-%m-%d")
    user["status"] = "active"
    return new_expire.strftime("%Y-%m-%d"), None

def change_package(contract_id: str, new_pkg_id: str):
    user = FAKE_USERS.get(contract_id)
    if not user:
        return None, "عقد غير موجود"
    if new_pkg_id not in PACKAGES:
        return None, "باقة غير موجودة"
    old_pkg = user["package_id"]
    user["package_id"] = new_pkg_id
    return PACKAGES[new_pkg_id], None

def fake_speedtest():
    return {
        "download": round(random.uniform(15, 95), 2),
        "upload": round(random.uniform(5, 45), 2),
        "ping": random.randint(5, 40),
        "jitter": random.randint(1, 8),
        "quality": random.choice(["ممتاز", "جيد جداً", "جيد"]),
    }
