"""دوال مساعدة للتنسيق"""
from datetime import datetime

def days_until(date_str: str) -> int:
    try:
        expire = datetime.strptime(date_str, "%Y-%m-%d")
        return (expire - datetime.now()).days
    except Exception:
        return 0

def status_emoji(status: str, days_left: int) -> str:
    if status == "expired" or days_left < 0:
        return "❌ منتهي"
    elif days_left <= 7:
        return f"⚠️ ينتهي قريباً ({days_left} أيام)"
    else:
        return f"✅ نشط ({days_left} يوم متبقي)"

def format_account(user: dict, pkg: dict) -> str:
    days = days_until(user["expire_date"])
    st = status_emoji(user["status"], days)
    return (
        f"👤 **حسابي - {user['name']}**\n"
        f"{'━' * 28}\n"
        f"📋 رقم العقد:  `{user['contract_id']}`\n"
        f"📞 الهاتف:     `{user['phone']}`\n"
        f"🏙️ المدينة:    {user['city']}\n"
        f"📍 العنوان:    {user['address']}\n"
        f"📧 البريد:     {user['email']}\n"
        f"{'━' * 28}\n"
        f"📦 الباقة:     **{pkg['name']}**\n"
        f"⬇️ سرعة التحميل: {pkg['speed']}\n"
        f"⬆️ سرعة الرفع:   {pkg['upload']}\n"
        f"📅 بداية:      {user['start_date']}\n"
        f"📅 انتهاء:     {user['expire_date']}\n"
        f"📶 الحالة:     {st}\n"
        f"💰 الرصيد:     **{user['balance']:.1f} د.ل**\n"
        f"📡 البرج:      {user.get('tower','—')}\n"
        f"📊 الإشارة:    {user.get('signal','—')}\n"
    )

def format_usage(user: dict, pkg: dict) -> str:
    used = user.get("usage_gb", 0)
    return (
        f"📊 **الاستهلاك الشهري**\n"
        f"{'━' * 28}\n"
        f"⬇️ تحميل:  {used:.1f} GB\n"
        f"⬆️ رفع:    {used * 0.3:.1f} GB\n"
        f"📦 الباقة: {pkg['name']} ({pkg['speed']})\n"
        f"📅 تحديث:  {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
    )

def format_package(pkg: dict) -> str:
    features = "\n".join(f"  ✔️ {f}" for f in pkg["features"])
    return (
        f"📦 **{pkg['name']}**\n"
        f"⬇️ تحميل: {pkg['speed']}  |  ⬆️ رفع: {pkg['upload']}\n"
        f"💰 شهري: {pkg['price_monthly']} د.ل  |  "
        f"3 أشهر: {pkg['price_3months']} د.ل  |  "
        f"سنة: {pkg['price_yearly']} د.ل\n"
        f"المميزات:\n{features}\n"
    )

def format_invoices(invoices: list) -> str:
    if not invoices:
        return "📄 لا توجد فواتير."
    lines = ["📄 **فواتيري**\n" + "━" * 28]
    for inv in invoices:
        icon = "✅" if inv["status"] == "paid" else "❌"
        lines.append(
            f"{icon} {inv['period']}\n"
            f"   المبلغ: {inv['amount']} د.ل  |  التاريخ: {inv['date']}\n"
            f"   رقم الفاتورة: `{inv['id']}`\n"
        )
    return "\n".join(lines)

def format_balance(user: dict, recharge_list: list) -> str:
    lines = [
        f"💰 **رصيدي**\n{'━'*28}\n"
        f"الرصيد الحالي: **{user['balance']:.1f} د.ل**\n\n"
        "📋 آخر عمليات الشحن:"
    ]
    if not recharge_list:
        lines.append("لا توجد عمليات سابقة.")
    for r in recharge_list[:5]:
        lines.append(f"  • {r['date']} | +{r['amount']} د.ل | {r['type']} ({r['ref']})")
    return "\n".join(lines)

def format_speed(result: dict) -> str:
    return (
        f"⚡ **نتيجة اختبار السرعة**\n"
        f"{'━' * 28}\n"
        f"⬇️ سرعة التحميل:  **{result['download']} Mbps**\n"
        f"⬆️ سرعة الرفع:    **{result['upload']} Mbps**\n"
        f"🏓 Ping:           **{result['ping']} ms**\n"
        f"📊 Jitter:         **{result['jitter']} ms**\n"
        f"🌟 جودة الاتصال:  **{result['quality']}**\n"
        f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
    )

def format_ticket(ticket: dict) -> str:
    status_icon = {"مفتوحة": "🔴", "قيد المعالجة": "🟡", "مغلقة": "🟢"}.get(ticket["status"], "⚪")
    return (
        f"🎫 **تذكرة #{ticket['id']}**\n"
        f"الفئة: {ticket['category']}\n"
        f"الحالة: {status_icon} {ticket['status']}\n"
        f"التاريخ: {ticket['created_at']}\n"
        f"الوصف: {ticket['description'][:100]}...\n" if len(ticket['description']) > 100
        else f"الوصف: {ticket['description']}\n"
    )
