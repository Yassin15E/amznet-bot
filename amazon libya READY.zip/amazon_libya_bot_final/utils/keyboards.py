"""لوحات المفاتيح والقوائم"""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove

# ─── القائمة الرئيسية ─────────────────────────────────────
def main_menu():
    kb = [
        ["👤 حسابي",          "🔄 تجديد الاشتراك"],
        ["📦 تغيير الباقة",   "💳 شحن كرت"],
        ["💰 رصيدي",          "📄 فواتيري"],
        ["📊 الاستهلاك",      "⚡ اختبار السرعة"],
        ["🎫 الدعم الفني",    "🎁 العروض"],
        ["📡 التغطية والأبراج","📞 تواصل معنا"],
        ["⚙️ الإعدادات"],
    ]
    return ReplyKeyboardMarkup(kb, resize_keyboard=True)

def admin_menu():
    kb = [
        ["👥 إدارة العملاء",   "📦 إدارة الباقات"],
        ["💳 إنشاء كروت",      "📄 إدارة الفواتير"],
        ["🎫 التذاكر",         "📢 إشعار جماعي"],
        ["📊 الإحصائيات",      "⬅️ رجوع للرئيسية"],
    ]
    return ReplyKeyboardMarkup(kb, resize_keyboard=True)

# ─── زر رجوع عام ─────────────────────────────────────────
def back_btn(data="back_main"):
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ رجوع", callback_data=data)]])

# ─── قائمة مدة التجديد ───────────────────────────────────
def renewal_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("1 شهر",  callback_data="renew_1")],
        [InlineKeyboardButton("3 أشهر", callback_data="renew_3")],
        [InlineKeyboardButton("سنة كاملة 🌟", callback_data="renew_12")],
        [InlineKeyboardButton("⬅️ رجوع", callback_data="back_main")],
    ])

# ─── قائمة الباقات ───────────────────────────────────────
def packages_keyboard(current_pkg_id=None, prefix="changepkg"):
    from data.fake_db import PACKAGES
    btns = []
    for pid, pkg in PACKAGES.items():
        label = f"{'✅ ' if pid == current_pkg_id else ''}{pkg['name']} - {pkg['price_monthly']} د.ل/شهر"
        btns.append([InlineKeyboardButton(label, callback_data=f"{prefix}_{pid}")])
    btns.append([InlineKeyboardButton("⬅️ رجوع", callback_data="back_main")])
    return InlineKeyboardMarkup(btns)

# ─── تذكرة الدعم: فئات المشاكل ──────────────────────────
def support_categories():
    cats = [
        ("🌐 انقطاع الإنترنت",    "support_internet"),
        ("🐢 بطء الاتصال",        "support_slow"),
        ("📶 ضعف الإشارة",        "support_signal"),
        ("💳 مشكلة في الدفع",     "support_payment"),
        ("📄 استفسار فاتورة",     "support_invoice"),
        ("🔄 طلب تجديد",          "support_renewal"),
        ("📦 تغيير باقة",         "support_package"),
        ("❓ استفسار عام",         "support_general"),
    ]
    btns = [[InlineKeyboardButton(name, callback_data=cdata)] for name, cdata in cats]
    btns.append([InlineKeyboardButton("⬅️ رجوع", callback_data="back_main")])
    return InlineKeyboardMarkup(btns)

# ─── تأكيد عملية ────────────────────────────────────────
def confirm_keyboard(confirm_data, cancel_data="back_main"):
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ تأكيد", callback_data=confirm_data),
            InlineKeyboardButton("❌ إلغاء", callback_data=cancel_data),
        ]
    ])

def settings_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔔 إدارة الإشعارات", callback_data="settings_notif")],
        [InlineKeyboardButton("📝 تحديث البيانات",  callback_data="settings_update")],
        [InlineKeyboardButton("🚪 تسجيل الخروج",    callback_data="settings_logout")],
        [InlineKeyboardButton("⬅️ رجوع",            callback_data="back_main")],
    ])
