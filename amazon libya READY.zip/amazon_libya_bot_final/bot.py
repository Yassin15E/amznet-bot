"""
🤖 بوت أمازون ليبيا للاتصالات والتقنية
نظام خدمة عملاء متكامل عبر تيليجرام
"""
import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ContextTypes, ConversationHandler, filters,
)

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data import fake_db as db
from utils import keyboards as kb
from utils import formatters as fmt

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8896317088:AAGmpySKGgws_FZ0ftxeimj80B-ijcugX_0")
ADMIN_IDS  = list(map(int, os.environ.get("ADMIN_IDS", "8489367565").split(",")))

# ─── Conversation states ──────────────────────────────────
(
    LOGIN_CONTRACT, LOGIN_PASSWORD,
    SUPPORT_DESC,
    CARD_INPUT,
    RENEW_CONFIRM,
    PKG_CONFIRM,
    ADMIN_BROADCAST,
    ADMIN_ADD_CLIENT_NAME, ADMIN_ADD_CLIENT_PHONE,
    ADMIN_ADD_CLIENT_CITY, ADMIN_ADD_CLIENT_PKG,
) = range(11)

SUPPORT_CATEGORY = {}   # temp store per user

# ══════════════════════════════════════════════════════════
#  /start  و  /help
# ══════════════════════════════════════════════════════════
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = db.get_session(update.effective_user.id)
    if user:
        client = db.get_user(user)
        await update.message.reply_text(
            f"مرحباً مجدداً، **{client['name']}** 👋\n"
            "اختر الخدمة التي تريدها:",
            parse_mode="Markdown",
            reply_markup=kb.main_menu(),
        )
    else:
        await update.message.reply_text(
            "🌐 **مرحباً بك في بوت أمازون ليبيا للاتصالات والتقنية**\n\n"
            "يُرجى تسجيل الدخول بإدخال **رقم العقد**:",
            parse_mode="Markdown",
        )
        return LOGIN_CONTRACT

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ **المساعدة**\n\n"
        "• `/start` — بدء / تسجيل الدخول\n"
        "• `/logout` — تسجيل الخروج\n"
        "• `/admin` — لوحة الأدمن (للمشرفين)\n\n"
        "📞 للتواصل: 021-123-4567",
        parse_mode="Markdown",
    )

async def cmd_logout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db.clear_session(update.effective_user.id)
    await update.message.reply_text(
        "👋 تم تسجيل الخروج بنجاح.\nأرسل /start للدخول مجدداً.",
    )

# ══════════════════════════════════════════════════════════
#  تسجيل الدخول
# ══════════════════════════════════════════════════════════
async def login_contract(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["contract_id"] = update.message.text.strip()
    await update.message.reply_text("🔑 أدخل كلمة المرور:")
    return LOGIN_PASSWORD

async def login_password(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    contract_id = ctx.user_data.get("contract_id", "")
    password    = update.message.text.strip()
    client = db.login(contract_id, password)
    if not client:
        await update.message.reply_text(
            "❌ **بيانات الدخول غير صحيحة.**\n"
            "تأكد من رقم العقد وكلمة المرور وحاول مجدداً.\n\n"
            "💡 حسابات تجريبية:\n"
            "`AMZN-001` / `1234`\n`AMZN-002` / `pass2`\n`AMZN-003` / `abc123`",
            parse_mode="Markdown",
        )
        return LOGIN_CONTRACT
    db.set_session(update.effective_user.id, contract_id)
    pkg = db.get_package(client["package_id"])
    days = fmt.days_until(client["expire_date"])
    warn = ""
    if days <= 7 and days >= 0:
        warn = f"\n⚠️ اشتراكك ينتهي خلال {days} أيام! استخدم 🔄 تجديد الاشتراك."
    elif days < 0:
        warn = "\n❌ اشتراكك منتهٍ! يُرجى التجديد."
    await update.message.reply_text(
        f"✅ **تم تسجيل الدخول بنجاح!**\n\n"
        f"أهلاً، **{client['name']}** 👋\n"
        f"باقتك الحالية: **{pkg['name']}**\n"
        f"الرصيد: **{client['balance']} د.ل**{warn}",
        parse_mode="Markdown",
        reply_markup=kb.main_menu(),
    )
    return ConversationHandler.END

# ══════════════════════════════════════════════════════════
#  دالة حماية (يجب تسجيل الدخول)
# ══════════════════════════════════════════════════════════
async def require_login(update: Update) -> str | None:
    cid = db.get_session(update.effective_user.id)
    if not cid:
        await update.message.reply_text(
            "⛔ يجب تسجيل الدخول أولاً.\nأرسل /start"
        )
        return None
    return cid

# ══════════════════════════════════════════════════════════
#  حسابي
# ══════════════════════════════════════════════════════════
async def my_account(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    user = db.get_user(cid)
    pkg  = db.get_package(user["package_id"])
    text = fmt.format_account(user, pkg)
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=kb.main_menu())

# ══════════════════════════════════════════════════════════
#  رصيدي
# ══════════════════════════════════════════════════════════
async def my_balance(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    user    = db.get_user(cid)
    history = db.FAKE_RECHARGE.get(cid, [])
    text = fmt.format_balance(user, history)
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  شحن كرت
# ══════════════════════════════════════════════════════════
async def card_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    await update.message.reply_text(
        "💳 **شحن كرت الرصيد**\n\n"
        "أدخل رقم الكرت المكون من 12 رقماً:\n"
        "_(مثال تجريبي: 123456789012)_",
        parse_mode="Markdown",
    )
    return CARD_INPUT

async def card_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid  = db.get_session(update.effective_user.id)
    card = update.message.text.strip()
    amount, error = db.recharge_card(cid, card)
    if error:
        await update.message.reply_text(f"❌ {error}", reply_markup=kb.main_menu())
    else:
        user = db.get_user(cid)
        await update.message.reply_text(
            f"✅ **تم شحن الرصيد بنجاح!**\n\n"
            f"💰 المبلغ المضاف: **{amount} د.ل**\n"
            f"💳 الرصيد الحالي: **{user['balance']:.1f} د.ل**",
            parse_mode="Markdown",
            reply_markup=kb.main_menu(),
        )
    return ConversationHandler.END

# ══════════════════════════════════════════════════════════
#  تجديد الاشتراك
# ══════════════════════════════════════════════════════════
async def renew_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    user = db.get_user(cid)
    pkg  = db.get_package(user["package_id"])
    await update.message.reply_text(
        f"🔄 **تجديد الاشتراك**\n\n"
        f"باقتك الحالية: **{pkg['name']}**\n"
        f"رصيدك الحالي: **{user['balance']:.1f} د.ل**\n\n"
        f"اختر مدة التجديد:",
        parse_mode="Markdown",
        reply_markup=kb.renewal_keyboard(),
    )

async def renew_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cid   = db.get_session(update.effective_user.id)
    user  = db.get_user(cid)
    pkg   = db.get_package(user["package_id"])
    months = int(query.data.split("_")[1])

    if months == 1:   cost = pkg["price_monthly"]
    elif months == 3: cost = pkg["price_3months"]
    else:             cost = pkg["price_yearly"]

    label = {1: "شهر", 3: "3 أشهر", 12: "سنة كاملة"}[months]
    ctx.user_data["renew_months"] = months

    await query.edit_message_text(
        f"🔄 **تأكيد التجديد**\n\n"
        f"المدة: **{label}**\n"
        f"التكلفة: **{cost} د.ل**\n"
        f"رصيدك: **{user['balance']:.1f} د.ل**\n\n"
        f"هل تريد المتابعة؟",
        parse_mode="Markdown",
        reply_markup=kb.confirm_keyboard(f"confirm_renew_{months}"),
    )

async def renew_confirm_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cid    = db.get_session(update.effective_user.id)
    months = int(query.data.split("_")[-1])
    new_date, error = db.renew_subscription(cid, months)
    if error:
        await query.edit_message_text(f"❌ {error}")
    else:
        await query.edit_message_text(
            f"✅ **تم التجديد بنجاح!**\n\n"
            f"📅 تاريخ الانتهاء الجديد: **{new_date}**",
            parse_mode="Markdown",
        )

# ══════════════════════════════════════════════════════════
#  تغيير الباقة
# ══════════════════════════════════════════════════════════
async def change_pkg_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    user = db.get_user(cid)
    text = "📦 **اختر الباقة الجديدة:**\n\n"
    for pkg in db.PACKAGES.values():
        text += fmt.format_package(pkg) + "\n"
    await update.message.reply_text(
        text, parse_mode="Markdown",
        reply_markup=kb.packages_keyboard(user["package_id"]),
    )

async def change_pkg_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cid    = db.get_session(update.effective_user.id)
    pkg_id = query.data.replace("changepkg_", "")
    user   = db.get_user(cid)

    if pkg_id == user["package_id"]:
        await query.answer("هذه هي باقتك الحالية!", show_alert=True)
        return

    pkg = db.get_package(pkg_id)
    ctx.user_data["new_pkg_id"] = pkg_id
    await query.edit_message_text(
        f"📦 **تأكيد تغيير الباقة**\n\n"
        f"الباقة الجديدة: **{pkg['name']}**\n"
        f"السرعة: {pkg['speed']}\n"
        f"السعر الشهري: {pkg['price_monthly']} د.ل\n\n"
        f"هل تريد التغيير؟",
        parse_mode="Markdown",
        reply_markup=kb.confirm_keyboard(f"confirm_pkg_{pkg_id}"),
    )

async def change_pkg_confirm(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cid    = db.get_session(update.effective_user.id)
    pkg_id = query.data.replace("confirm_pkg_", "")
    new_pkg, error = db.change_package(cid, pkg_id)
    if error:
        await query.edit_message_text(f"❌ {error}")
    else:
        await query.edit_message_text(
            f"✅ **تم تغيير الباقة بنجاح!**\n\n"
            f"باقتك الجديدة: **{new_pkg['name']}**\n"
            f"السرعة: {new_pkg['speed']}",
            parse_mode="Markdown",
        )

# ══════════════════════════════════════════════════════════
#  الفواتير
# ══════════════════════════════════════════════════════════
async def my_invoices(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    invoices = db.FAKE_INVOICES.get(cid, [])
    text = fmt.format_invoices(invoices)
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  الاستهلاك
# ══════════════════════════════════════════════════════════
async def my_usage(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    user = db.get_user(cid)
    pkg  = db.get_package(user["package_id"])
    text = fmt.format_usage(user, pkg)
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  اختبار السرعة
# ══════════════════════════════════════════════════════════
async def speed_test(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    msg = await update.message.reply_text("⚡ جاري اختبار السرعة... يرجى الانتظار")
    import asyncio; await asyncio.sleep(2)
    result = db.fake_speedtest()
    await msg.edit_text(fmt.format_speed(result), parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  الدعم الفني
# ══════════════════════════════════════════════════════════
async def support_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return

    tickets = db.get_tickets(cid)
    tickets_text = ""
    if tickets:
        tickets_text = "\n\n📋 **تذاكرك السابقة:**\n"
        for t in tickets[-3:]:
            tickets_text += fmt.format_ticket(t)

    await update.message.reply_text(
        f"🎫 **الدعم الفني**\n\n"
        f"اختر نوع المشكلة:{tickets_text}",
        parse_mode="Markdown",
        reply_markup=kb.support_categories(),
    )

async def support_category_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cat_map = {
        "support_internet": "انقطاع الإنترنت",
        "support_slow":     "بطء الاتصال",
        "support_signal":   "ضعف الإشارة",
        "support_payment":  "مشكلة في الدفع",
        "support_invoice":  "استفسار فاتورة",
        "support_renewal":  "طلب تجديد",
        "support_package":  "تغيير باقة",
        "support_general":  "استفسار عام",
    }
    cat = cat_map.get(query.data, "استفسار عام")
    SUPPORT_CATEGORY[update.effective_user.id] = cat
    await query.edit_message_text(
        f"📝 **{cat}**\n\nاكتب وصفاً تفصيلياً للمشكلة:",
        parse_mode="Markdown",
    )
    return SUPPORT_DESC

async def support_desc(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid  = db.get_session(update.effective_user.id)
    cat  = SUPPORT_CATEGORY.pop(update.effective_user.id, "استفسار عام")
    desc = update.message.text
    ticket = db.add_ticket(cid, cat, desc)

    # إشعار الأدمن
    for admin_id in ADMIN_IDS:
        try:
            await ctx.bot.send_message(
                admin_id,
                f"🎫 **تذكرة جديدة {ticket['id']}**\n"
                f"العقد: `{cid}`\nالفئة: {cat}\n\n{desc}",
                parse_mode="Markdown",
            )
        except Exception:
            pass

    await update.message.reply_text(
        f"✅ **تم فتح التذكرة بنجاح!**\n\n"
        f"رقم التذكرة: **{ticket['id']}**\n"
        f"الفئة: {cat}\n"
        f"سيتم التواصل معك قريباً. 🙏",
        parse_mode="Markdown",
        reply_markup=kb.main_menu(),
    )
    return ConversationHandler.END

# ══════════════════════════════════════════════════════════
#  العروض
# ══════════════════════════════════════════════════════════
async def show_offers(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = "🎁 **العروض الحالية**\n" + "━" * 28 + "\n\n"
    for offer in db.FAKE_OFFERS:
        text += (
            f"{offer['title']}\n"
            f"📝 {offer['desc']}\n"
            f"🏷️ الخصم: {offer['discount']}\n"
            f"📅 حتى: {offer['valid_until']}\n"
            f"{'─' * 24}\n"
        )
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  التغطية والأبراج
# ══════════════════════════════════════════════════════════
async def show_coverage(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = "📡 **التغطية والأبراج**\n" + "━" * 28 + "\n\n"
    for tower in db.FAKE_TOWERS:
        text += (
            f"🏙️ **{tower['city']}** — {tower['name']}\n"
            f"   📍 المناطق: {tower['areas']}\n"
            f"   📶 الإشارة: {tower['signal']}  |  النوع: {tower['type']}\n\n"
        )
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  تواصل معنا
# ══════════════════════════════════════════════════════════
async def contact_us(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    info = db.CONTACT_INFO
    text = (
        "📞 **تواصل معنا**\n" + "━" * 28 + "\n\n"
        f"الهواتف:\n" + "\n".join(f"  {p}" for p in info["phones"]) + "\n\n"
        f"💬 واتساب: `{info['whatsapp']}`\n"
        f"📧 البريد: {info['email']}\n"
        f"🌐 الموقع: {info['website']}\n"
        f"👤 فيسبوك: {info['facebook']}\n\n"
        f"📍 العنوان:\n{info['address']}\n\n"
        f"⏰ ساعات العمل:\n{info['hours']}"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════
#  الإعدادات
# ══════════════════════════════════════════════════════════
async def settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = await require_login(update)
    if not cid: return
    await update.message.reply_text(
        "⚙️ **الإعدادات**", parse_mode="Markdown",
        reply_markup=kb.settings_keyboard(),
    )

async def settings_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == "settings_logout":
        db.clear_session(update.effective_user.id)
        await query.edit_message_text("👋 تم تسجيل الخروج. أرسل /start للدخول مجدداً.")
    elif query.data == "settings_notif":
        await query.edit_message_text(
            "🔔 **الإشعارات**\n\nجميع الإشعارات مفعّلة:\n"
            "✅ إشعار انتهاء الاشتراك\n✅ إشعار انخفاض الرصيد\n✅ تحديث التذاكر",
            parse_mode="Markdown",
            reply_markup=kb.back_btn(),
        )
    elif query.data == "settings_update":
        await query.edit_message_text(
            "📝 لتحديث بياناتك، تواصل مع الدعم الفني عبر 🎫 الدعم الفني",
            reply_markup=kb.back_btn(),
        )
    elif query.data == "back_main":
        await query.edit_message_text("تم الرجوع للقائمة الرئيسية.")

# ══════════════════════════════════════════════════════════
#  لوحة الأدمن
# ══════════════════════════════════════════════════════════
async def cmd_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ غير مصرح.")
        return
    total     = len(db.FAKE_USERS)
    active    = sum(1 for u in db.FAKE_USERS.values() if u["status"] == "active")
    expired   = total - active
    tickets   = sum(len(v) for v in db.FAKE_TICKETS.values())
    await update.message.reply_text(
        f"⚙️ **لوحة إدارة أمازون ليبيا**\n{'━'*28}\n"
        f"👥 إجمالي العملاء: {total}\n"
        f"✅ نشطون: {active}  |  ❌ منتهٍ: {expired}\n"
        f"🎫 تذاكر دعم: {tickets}",
        parse_mode="Markdown",
        reply_markup=kb.admin_menu(),
    )

async def admin_clients(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS: return
    text = "👥 **قائمة العملاء**\n" + "━"*28 + "\n\n"
    for u in db.FAKE_USERS.values():
        pkg  = db.get_package(u["package_id"])
        days = fmt.days_until(u["expire_date"])
        icon = "✅" if days > 7 else ("⚠️" if days >= 0 else "❌")
        text += f"{icon} `{u['contract_id']}` | {u['name']} | {pkg['name']} | {days}d\n"
    await update.message.reply_text(text, parse_mode="Markdown")

async def admin_tickets(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS: return
    if not db.FAKE_TICKETS:
        await update.message.reply_text("✅ لا توجد تذاكر.")
        return
    text = "🎫 **جميع التذاكر**\n" + "━"*28 + "\n"
    for cid, tickets in db.FAKE_TICKETS.items():
        for t in tickets:
            text += fmt.format_ticket(t) + "\n"
    await update.message.reply_text(text, parse_mode="Markdown")

async def admin_broadcast_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS: return
    await update.message.reply_text("📢 اكتب الرسالة التي تريد إرسالها لجميع العملاء:")
    return ADMIN_BROADCAST

async def admin_broadcast_send(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg  = update.message.text
    sent = 0
    for session_tid, cid in db.SESSIONS.items():
        try:
            await ctx.bot.send_message(
                session_tid,
                f"📢 **رسالة من أمازون ليبيا**\n\n{msg}",
                parse_mode="Markdown",
            )
            sent += 1
        except Exception:
            pass
    await update.message.reply_text(
        f"✅ تم إرسال الإشعار لـ {sent} عميل نشط.",
        reply_markup=kb.admin_menu(),
    )
    return ConversationHandler.END

async def admin_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS: return
    pkg_count = {}
    for u in db.FAKE_USERS.values():
        pkg_count[u["package_id"]] = pkg_count.get(u["package_id"], 0) + 1
    text = "📊 **إحصائيات الباقات**\n" + "━"*28 + "\n"
    for pid, count in pkg_count.items():
        text += f"  • {db.PACKAGES[pid]['name']}: {count} عميل\n"
    await update.message.reply_text(text, parse_mode="Markdown")

async def back_main(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("تم الرجوع.")

async def cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ تم الإلغاء.", reply_markup=kb.main_menu())
    return ConversationHandler.END

# ══════════════════════════════════════════════════════════
#  تشغيل البوت
# ══════════════════════════════════════════════════════════
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # ─ تسجيل الدخول ─
    login_conv = ConversationHandler(
        entry_points=[CommandHandler("start", cmd_start)],
        states={
            LOGIN_CONTRACT: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_contract)],
            LOGIN_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, login_password)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # ─ شحن الكرت ─
    card_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^💳 شحن كرت$"), card_start)],
        states={CARD_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, card_input)]},
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # ─ الدعم الفني ─
    support_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🎫 الدعم الفني$"), support_start)],
        states={SUPPORT_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, support_desc)]},
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # ─ إشعار جماعي ─
    broadcast_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📢 إشعار جماعي$"), admin_broadcast_start)],
        states={ADMIN_BROADCAST: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_broadcast_send)]},
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # ─ تسجيل الـ handlers ─
    app.add_handler(login_conv)
    app.add_handler(card_conv)
    app.add_handler(support_conv)
    app.add_handler(broadcast_conv)

    app.add_handler(CommandHandler("help",   cmd_help))
    app.add_handler(CommandHandler("logout", cmd_logout))
    app.add_handler(CommandHandler("admin",  cmd_admin))

    app.add_handler(MessageHandler(filters.Regex("^👤 حسابي$"),              my_account))
    app.add_handler(MessageHandler(filters.Regex("^💰 رصيدي$"),              my_balance))
    app.add_handler(MessageHandler(filters.Regex("^📄 فواتيري$"),            my_invoices))
    app.add_handler(MessageHandler(filters.Regex("^📊 الاستهلاك$"),          my_usage))
    app.add_handler(MessageHandler(filters.Regex("^⚡ اختبار السرعة$"),      speed_test))
    app.add_handler(MessageHandler(filters.Regex("^🎁 العروض$"),             show_offers))
    app.add_handler(MessageHandler(filters.Regex("^📡 التغطية والأبراج$"),   show_coverage))
    app.add_handler(MessageHandler(filters.Regex("^📞 تواصل معنا$"),         contact_us))
    app.add_handler(MessageHandler(filters.Regex("^⚙️ الإعدادات$"),          settings))
    app.add_handler(MessageHandler(filters.Regex("^🔄 تجديد الاشتراك$"),     renew_start))
    app.add_handler(MessageHandler(filters.Regex("^📦 تغيير الباقة$"),       change_pkg_start))

    # أدمن
    app.add_handler(MessageHandler(filters.Regex("^👥 إدارة العملاء$"),  admin_clients))
    app.add_handler(MessageHandler(filters.Regex("^🎫 التذاكر$"),        admin_tickets))
    app.add_handler(MessageHandler(filters.Regex("^📊 الإحصائيات$"),     admin_stats))
    app.add_handler(MessageHandler(filters.Regex("^⬅️ رجوع للرئيسية$"), cmd_start))

    # كولباك
    app.add_handler(CallbackQueryHandler(renew_callback,        pattern="^renew_[0-9]+$"))
    app.add_handler(CallbackQueryHandler(renew_confirm_callback,pattern="^confirm_renew_"))
    app.add_handler(CallbackQueryHandler(change_pkg_callback,   pattern="^changepkg_"))
    app.add_handler(CallbackQueryHandler(change_pkg_confirm,    pattern="^confirm_pkg_"))
    app.add_handler(CallbackQueryHandler(support_category_callback, pattern="^support_"))
    app.add_handler(CallbackQueryHandler(settings_callback,     pattern="^settings_|^back_main$"))

    logger.info("🤖 بوت أمازون ليبيا يعمل...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
